  <div id="layoutSidenav_nav">
      <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
          <div class="sb-sidenav-menu">
              <div class="nav">
                  <div class="sb-sidenav-menu-heading">Core</div>
                  <a class="nav-link" href="welcome.php">
                      <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                      Dashboard
                  </a>


                  <a class="nav-link" href="profile.php">
                      <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                      Profile
                  </a>
                  <!-- <a class="nav-link" href="edit.php">
                      <div class="sb-nav-link-icon"><i class="fas fa-edit"></i></div>
                      edit news
                  </a> -->
                  <!-- <a class="nav-link" href="delete.php">
                      <div class="sb-nav-link-icon"><i class="fas fa-trash"></i></div>
                      delete news
                  </a> -->
                  <a class="nav-link" href="message.php">
                      <div class="sb-nav-link-icon"><i class="fas fa-list"></i></div>
                      news list
                  </a>
                  <a class="nav-link" href="insert.php">
                      <div class="sb-nav-link-icon"><i class="fas fa-plus"></i></div>
                      Add Post news
                  </a>


                  <a class="nav-link" href="change-password.php">
                      <div class="sb-nav-link-icon"><i class="fas fa-key"></i></div>
                      Change Password
                  </a>

                  <a class="nav-link" href="logout.php">
                      <div class="sb-nav-link-icon"><i class="fas fa-sign-out-alt"></i></div>
                      Signout
                  </a>
              </div>
          </div>

      </nav>
  </div>